// Modal logic
const tiles = document.querySelectorAll('.tile');
const modal = document.getElementById('modal');
const modalTitle = document.getElementById('modal-title');
const modalDesc = document.getElementById('modal-desc');
const modalClose = document.getElementById('modal-close');

tiles.forEach(tile => {
  tile.addEventListener('click', () => {
    modalTitle.textContent = tile.dataset.title;
    modalDesc.textContent = tile.dataset.desc;
    modal.style.display = 'flex';
  });
});

modalClose.addEventListener('click', () => {
  modal.style.display = 'none';
});

window.addEventListener('click', e => {
  if (e.target === modal) {
    modal.style.display = 'none';
  }
});

// GSAP Animation
gsap.from('.tile', {
  opacity: 0,
  y: 100,
  stagger: 0.2,
  duration: 1,
  ease: 'back.out(1.7)'
});
